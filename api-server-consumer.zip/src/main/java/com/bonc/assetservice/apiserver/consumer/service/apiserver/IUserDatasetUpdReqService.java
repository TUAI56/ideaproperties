package com.bonc.assetservice.apiserver.consumer.service.apiserver;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bonc.assetservice.apiserver.data.entity.UserDatasetUpdReq;

/**
 * @Description: user_dataset_upd_req
 * @Author: jeecg-boot
 * @Date:   2022-06-30
 * @Version: V1.0
 */
public interface IUserDatasetUpdReqService extends IService<UserDatasetUpdReq> {

    boolean updateState(Long id, Integer state);
}
