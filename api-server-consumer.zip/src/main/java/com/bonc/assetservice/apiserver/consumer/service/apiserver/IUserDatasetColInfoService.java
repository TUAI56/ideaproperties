package com.bonc.assetservice.apiserver.consumer.service.apiserver;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bonc.assetservice.apiserver.data.entity.UserDatasetColInfo;

/**
 * @Description: tenant_info
 * @Author: jeecg-boot
 * @Date:   2022-06-30
 * @Version: V1.0
 */
public interface IUserDatasetColInfoService extends IService<UserDatasetColInfo> {

}
